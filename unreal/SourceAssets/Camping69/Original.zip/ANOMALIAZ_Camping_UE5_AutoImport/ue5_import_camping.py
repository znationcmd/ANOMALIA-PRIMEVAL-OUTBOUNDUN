"""ANOMALIA'Z PRIGIMALIA - safe UE5 editor import of camping GLB models.
Run inside Unreal Editor Python (Python Editor Script Plugin and Interchange glTF enabled).
Set ANOMALIAZ_CAMPING_ZIP to a local synced copy of the ZIP, or place it in
D:/ANOMALIA/Imports/ANOMALIAZ_Camping_6_Objets_Ampoule_Universelle_3D.zip.
This script imports assets ONLY. It does not attach them to Blueprints, inventory or vehicles.
"""
import os
import zipfile
import tempfile
import unreal

ZIP_NAME = 'ANOMALIAZ_Camping_6_Objets_Ampoule_Universelle_3D.zip'
ZIP_CANDIDATES = [
    os.environ.get('ANOMALIAZ_CAMPING_ZIP', ''),
    os.path.join('D:/ANOMALIA/Imports', ZIP_NAME),
    os.path.join('D:/ANOMALIA', ZIP_NAME),
]
DESTINATION = '/Game/ANOMALIAZ/Items/CampingAndVehicleBulbs'
EXPECTED = [
    'CampingGasCanister_Small.glb',
    'CampingGasCanister_Medium.glb',
    'CampingGasCanister_Large.glb',
    'CampingGasStove_Burner.glb',
    'CampingGasTorch_Head.glb',
    'CampingGasLantern_Head.glb',
    'UniversalVehicleHeadlightBulb.glb',
]

def log(msg):
    unreal.log('[ANOMALIAZ CAMPING] ' + msg)

def main():
    path = next((p for p in ZIP_CANDIDATES if p and os.path.isfile(p)), None)
    if not path:
        raise FileNotFoundError('Pack local absent. Placez le ZIP dans D:/ANOMALIA/Imports ou définissez ANOMALIAZ_CAMPING_ZIP.')
    if not zipfile.is_zipfile(path):
        raise ValueError('Archive ZIP invalide: ' + path)
    unreal.EditorAssetLibrary.make_directory(DESTINATION)
    imported, skipped = [], []
    with zipfile.ZipFile(path) as archive, tempfile.TemporaryDirectory(prefix='anomaliaz_camping_') as temp:
        members = {os.path.basename(x): x for x in archive.namelist() if x.lower().endswith('.glb')}
        missing = [name for name in EXPECTED if name not in members]
        if missing:
            raise ValueError('Fichiers GLB manquants : ' + ', '.join(missing))
        for name in EXPECTED:
            stem = os.path.splitext(name)[0]
            target = DESTINATION + '/' + stem
            if unreal.EditorAssetLibrary.does_asset_exist(target):
                skipped.append(stem)
                continue
            extracted = os.path.join(temp, name)
            with open(extracted, 'wb') as output:
                output.write(archive.read(members[name]))
            task = unreal.AssetImportTask()
            task.set_editor_property('filename', extracted)
            task.set_editor_property('destination_path', DESTINATION)
            task.set_editor_property('automated', True)
            task.set_editor_property('replace_existing', False)
            task.set_editor_property('save', True)
            unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
            paths = task.get_editor_property('imported_object_paths')
            if not paths:
                raise RuntimeError('Import échoué pour ' + name + '. Vérifiez le plugin Interchange glTF et le journal UE5.')
            imported.append((name, [str(x) for x in paths]))
    log('Import terminé. Importés: {}. Ignorés (déjà présents): {}.'.format(len(imported), len(skipped)))
    for name, objects in imported:
        log('{} -> {}'.format(name, ', '.join(objects)))
    if skipped:
        log('Non écrasés : ' + ', '.join(skipped))
    log('À FAIRE: branchement des items à l’inventaire, supports de cartouche, effets lumineux et sockets des véhicules.')

main()
