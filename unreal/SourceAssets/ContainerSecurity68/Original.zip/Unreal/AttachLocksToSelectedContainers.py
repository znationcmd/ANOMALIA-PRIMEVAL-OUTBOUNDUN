# ANOMALIA'Z PRIGIMALIA — UE5 Editor Python
# Adds a visible lock to selected container actors. Does NOT change game runtime or save levels.
# Requires imported StaticMesh assets (see README). Choose a color, select containers in level, run.
import unreal

COLOR = "Blue"  # Blue, Red, Green, Orange, Yellow, White
LOCK_FOLDER = "/Game/ANOMALIAZ/Items/ContainerLocks/Locks"
OFFSET_CM = unreal.Vector(0.0, 0.0, 0.0) # tweak for different container door geometries
ALLOWED = {"Blue", "Red", "Green", "Orange", "Yellow", "White"}
if COLOR not in ALLOWED:
    raise ValueError("Unsupported lock color")

mesh_path = f"{LOCK_FOLDER}/ContainerLock_{COLOR}"
lock_mesh = unreal.load_asset(mesh_path)
if not lock_mesh or not isinstance(lock_mesh, unreal.StaticMesh):
    raise RuntimeError(f"Import lock GLB as a Static Mesh first: {mesh_path}")

editor = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
selected = list(editor.get_selected_level_actors())
if not selected:
    raise RuntimeError("Select one or more CONTAINER actors in the open level first")

made = 0
for container in selected:
    # Use actor bounding box as a safe initial approximate door location.
    center, extents = container.get_actor_bounds(False)
    door_world = center + container.get_actor_forward_vector() * extents.x
    door_world += unreal.Vector(0,0, min(20.0, extents.z * 0.2)) + OFFSET_CM
    lock_actor = editor.spawn_actor_from_class(unreal.StaticMeshActor, door_world, container.get_actor_rotation())
    lock_actor.set_actor_label(f"AZ_ContainerLock_{COLOR}_{container.get_actor_label()}")
    lock_actor.static_mesh_component.set_static_mesh(lock_mesh)
    lock_actor.set_editor_property("tags", [unreal.Name("AZ_ContainerLock"), unreal.Name(f"AZ_Key_{COLOR}")])
    # Relative transform after attachment: prevent lock drifting if the container moves in editor.
    lock_actor.attach_to_actor(container, "", unreal.AttachmentRule.KEEP_WORLD, unreal.AttachmentRule.KEEP_WORLD, unreal.AttachmentRule.KEEP_WORLD, False)
    made += 1
unreal.log(f"ANOMALIA'Z: attached {made} {COLOR} lock(s). Inspect alignment and save level manually.")
