# ANOMALIA’Z PRIGIMALIA — pack conteneurs à serrures

Ce pack comprend 6 clés et 6 serrures (GLB et OBJ), et un script **éditeur** Unreal Engine 5 permettant d'attacher visuellement une serrure à un acteur conteneur déjà placé dans une carte.

## Installation sans écraser le projet

1. Décompresser le pack hors de `D:\ANOMALIA` pour sauvegarder l’original.
2. Ouvrir le vrai projet Unreal Engine 5.8 d'ANOMALIA’Z.
3. Activer le plugin **Interchange** compatible GLB et **Python Editor Script Plugin** si nécessaire.
4. Importer les six fichiers `Models/Locks/ContainerLock_*.glb` dans `/Game/ANOMALIAZ/Items/ContainerLocks/Locks/` (les noms d'assets doivent rester `ContainerLock_Blue`, etc.). Importer les six clés `Models/Keys/ContainerKey_*.glb` dans `/Game/ANOMALIAZ/Items/ContainerLocks/Keys/`.
5. Faire une copie de sauvegarde de la carte, sélectionner les acteurs conteneurs à traiter dans le niveau UE5 et ouvrir `Unreal/AttachLocksToSelectedContainers.py` dans l'outil Python de l'éditeur.
6. Régler `COLOR` au début du script, exécuter, vérifier la position sur la porte dans l'éditeur et ajuster `OFFSET_CM` ou déplacer manuellement les serrures avant de sauvegarder la carte.
7. Répéter par couleur selon les zones/tiers prévus.

## Limites essentielles

- **Visuel et liaison éditoriale uniquement** : les serrures sont attachées aux acteurs conteneurs sélectionnés, et ne sont pas fusionnées au fichier mesh du conteneur.
- Pour rendre les portes réellement verrouillées, connecter la serrure à la **Blueprint d'ouverture déjà utilisée** par les conteneurs, et au **système d'inventaire existant** du joueur. La condition attendue est `PlayerHasItem(container_key_<color>)`. Ne consommer la clé que si les règles du gameplay le demandent.
- Prévoir l'interaction serveur autoritaire, la réplication de `bIsLocked` et `bIsOpen` et la persistance des états selon le framework de sauvegarde réel.
- Si les conteneurs ont des meshes différents, ajuster la position de la serrure sur chaque porte. Le script place un point de départ approximatif à l'avant de la boîte englobante.
- Le script ne crée **aucune animation de porte**, n'accorde **aucun loot**, ne fait **aucune compilation** et n'est **pas installé sur ton PC**. Il ne modifie aucun fichier projet existant automatiquement.

## Correspondance

Bleue ↔ bleue ; rouge ↔ rouge ; verte ↔ verte ; orange ↔ orange ; jaune ↔ jaune ; blanche ↔ blanche.

Pour une intégration finale au gameplay, identifier les vrais Blueprints/StaticMeshes des conteneurs, inventaire et interactions dans `D:\ANOMALIA` avant de modifier le projet.
